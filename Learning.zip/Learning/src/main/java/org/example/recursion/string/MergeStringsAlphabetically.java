package org.example.recursion.string;

public class MergeStringsAlphabetically {

    static String merge(String str1, String str2){
        if(str1.length() == 0)
            return str2;
        if(str2.length() == 0)
            return str1;

        if(str1.substring(0,1).compareTo(str2.substring(0,1)) <= 0 ){
            return str1.substring(0,1) + merge(str1.substring(1), str2);
        } else{
            return str2.substring(0,1) + merge(str1, str2.substring(1));
        }
    }
/*
    private static String alphabeticMerge(String one, String two) {
        if (one == null || one.equals("")) {
            return two==null? one:two;
        }
        else if (two == null || two.equals("")) {
            return one;
        }
        else if (two.charAt(0) > one.charAt(0)) {
            return one.charAt(0) + alphabeticMerge(one.substring(1, one.length()), two);
        }
        else {
            return two.charAt(0) + alphabeticMerge(one, two.substring(1, two.length()));
        }
    }
*/
    public static void main(String[] args) {
        String testStr = "ABCDE";
        //System.out.println(testStr.substring(1) + " - " + testStr);
        System.out.println(merge("cntuv", "abce"));
    }
}
