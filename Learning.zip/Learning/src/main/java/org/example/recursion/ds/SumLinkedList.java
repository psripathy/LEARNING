package org.example.recursion.ds;

import org.example.collections.list.LinkedList;
import org.example.collections.list.LinkedListNode;

public class SumLinkedList {

    private static int findSum(LinkedListNode head) {
        if(head == null)
            return 0;
        else
            return head.data + findSum(head.next);
    }

    static boolean isExists(LinkedListNode head, int key){

        if(head == null){
            return false;
        }
        if(head.data == key)
            return true;
        else {
            return isExists(head.next, key);
        }
    }

    public static void main(String[] args) {

        LinkedList<Integer> input = new LinkedList<>();
        input.createLinkedList(new int[]{1,2,3,4,5});
        input.printLinkedList();
        System.out.println("\n-----------------");
        System.out.println(findSum(input.head));
        System.out.println(isExists(input.head, 4));
    }
}
