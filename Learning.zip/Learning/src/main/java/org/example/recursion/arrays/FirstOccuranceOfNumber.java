package org.example.recursion.arrays;

import java.util.Arrays;

public class FirstOccuranceOfNumber {

    static int firstIndex(int[] arr, int key, int currIndex){

        if(currIndex == arr.length){
            return -1;
        } else {
            return arr[currIndex] == key ? currIndex : firstIndex(arr, key, ++currIndex);
        }
    }

    static int numOfOccurances(int[] arr, int key, int currIndex){

        int count = 0;
        if(currIndex == arr.length){
            return 0;
        } else {
            if(arr[currIndex] == key)
                count += 1;
            return count + numOfOccurances(arr, key, ++currIndex);
        }
    }

    static void replaceNegativeNum(int[] arr, int currIndex){

        if(currIndex == arr.length){
            return;
        } else {
            if(arr[currIndex] < 0)
                arr[currIndex] = 0;
            replaceNegativeNum(arr, ++currIndex);
        }
    }

    public static void main(String[] args) {
        System.out.println(firstIndex(new int[]{2,3,4,1,7,8,3}, 3, 0));
        System.out.println(numOfOccurances(new int[]{2,3,4,1,7,8,3}, 3, 0));
        int[] arr = new int[]{2,-3,4,1,7,8,-3};
        replaceNegativeNum(arr, 0);
        Arrays.stream(arr).forEach(s -> System.out.print(s + ", "));
    }
}
