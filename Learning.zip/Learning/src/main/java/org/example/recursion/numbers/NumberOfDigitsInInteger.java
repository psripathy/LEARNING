package org.example.recursion.numbers;

public class NumberOfDigitsInInteger {
    static int countByIteration(int num){
        int count = 0;
        while (num>0){
            num = num/10;
            count++;
        }
        return count;
    }

    static int countByRecursion(int num){
        int count = 0;
        if(num == 0){
            return 0;
        }else {
            return 1+countByRecursion(num/10);
        }
    }

    public static void main(String[] args) {
        System.out.println(countByIteration(1234));
        System.out.println(countByRecursion(1234));
    }
}
