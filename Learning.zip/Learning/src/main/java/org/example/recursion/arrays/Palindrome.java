package org.example.recursion.arrays;

public class Palindrome {

    static boolean isPalindrome(int[] array, int idx){

        int lastIdx = array.length-1;
        if(idx == array.length/2)
            return true;
        if(array[idx] != array[lastIdx-idx])
            return false;
        else
            return isPalindrome(array, ++idx);
    }

    public static void main(String[] args) {
        int[] arr1 = new int[]{1,2,3,2,1};
        int[] arr2 = new int[]{1,2,3,1};

        System.out.println(isPalindrome(arr1, 0));
        System.out.println(isPalindrome(arr2, 0));
    }
}
