package org.example.recursion.arrays;

import java.util.Arrays;

public class SortArray {

    static void sort(int[] array, int length){

        if(length == 1)
            return;
        else{
            for(int i=0; i<length-1; i++){
                if(array[i] > array[i+1]){
                    var temp = array[i];
                    array[i] = array[i+1];
                    array[i+1] = temp;
                }
            }
            sort(array, length-1);
        }
    }

    public static void main(String[] args) {
        int[] arr1 = {3,2,4,5,1};
        sort(arr1, arr1.length);
        Arrays.stream(arr1).forEach(i -> System.out.print(i+","));

    }
}
