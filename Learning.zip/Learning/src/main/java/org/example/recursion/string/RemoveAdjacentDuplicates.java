package org.example.recursion.string;

public class RemoveAdjacentDuplicates {

    static String removeDuplicate(String inputStr){

        if(inputStr.length() == 1)
            return inputStr;
        if(inputStr.substring(0,1).equalsIgnoreCase(inputStr.substring(1,2))){
            return removeDuplicate(inputStr.substring(1));
        }else {
            return inputStr.substring(0,1) + removeDuplicate(inputStr.substring(1));
        }

    }

    public static void main(String[] args) {
        System.out.println(removeDuplicate("HellLo"));
    }
}
