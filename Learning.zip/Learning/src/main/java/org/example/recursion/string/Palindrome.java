package org.example.recursion.string;

public class Palindrome {

    static Object isPalindrome(String str){
        String reversed = "";
        if(str.length() == 1){
            reversed += str;
        } else {
            reversed += str.substring(str.length() - 1) + isPalindrome(str.substring(0, str.length() - 1));
        }
        //System.out.println("reversed >> " + reversed);
        return reversed;

        //return true;
    }

    public static void main(String[] args) {
        String test = "liril";
        System.out.println(isPalindrome(test).equals("liril"));
        System.out.println(isPalindrome("abcd").equals("abcd"));
    }
}
