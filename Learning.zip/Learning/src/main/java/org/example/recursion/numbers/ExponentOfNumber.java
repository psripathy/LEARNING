package org.example.recursion.numbers;

public class ExponentOfNumber {

    static int getExponent(int base, int pow){

        if(pow == 0)
            return 1;
        else {
            return base * getExponent(base, pow-1);
        }
    }

    public static void main(String[] args) {
        System.out.println(getExponent(2, 3));
    }
}
