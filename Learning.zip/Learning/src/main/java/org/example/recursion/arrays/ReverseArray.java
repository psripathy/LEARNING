package org.example.recursion.arrays;

import java.util.Arrays;

public class ReverseArray {

    static void reverseArray(int[] array, int currentIndex){
        int lastIndex = array.length -1;
        if(currentIndex+1 <= lastIndex-currentIndex){
            var temp = array[currentIndex];
            array[currentIndex] = array[lastIndex-currentIndex];
            array[lastIndex-currentIndex] = temp;
            reverseArray(array, ++currentIndex);
        }else {
            return;
        }
    }

    public static void main(String[] args) {
        int[] arr1 = new int[]{1,2,3,4,5,6};
        int[] arr2 = new int[]{1,2,3,4,5,6,7};
        reverseArray(arr1, 0);
        reverseArray(arr2, 0);
        Arrays.stream(arr1).forEach(s -> System.out.print(s + ",") );
        System.out.println("\n-----------------");
        Arrays.stream(arr2).forEach(s -> System.out.print(s + ",") );
    }
}
