package org.example.recursion.numbers;

public class Factorial {

    static int factorialByIteration(int num){
        int factorial = 1;

        while(num > 1){
            factorial *= num--;
        }
        return factorial;
    }

    static int factorialByRecursion(int num){
        if(num == 1)
            return 1;
        else {
            return num * factorialByRecursion(num-1);
        }
    }

    public static void main(String[] args) {
        System.out.println(factorialByIteration(5));
        System.out.println(factorialByRecursion(5));
    }
}
