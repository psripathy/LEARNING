package org.example.recursion.numbers;

public class IntToBinary {
    public static int decimalToBinary(int decimalNum) {
        System.out.println("num = " + decimalNum);
        if (decimalNum == 0) {
            System.out.println("----------------");
            return 0;
        }
        else {
            var mod = decimalNum%2;
            System.out.println("mod("+decimalNum+"%2) = " + mod);
            var div = decimalToBinary(decimalNum/2);
            var bin = (mod + 10*div);
            System.out.println("10*div("+decimalNum+"/2)  = " + div);

            return bin;
        }
    }

    public static void main(String[] args) {
        System.out.println(decimalToBinary(9));
    }
}
