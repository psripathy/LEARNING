package org.example.recursion.numbers;

public class Fibonacci {

    static int printFibonacci(int num){

        if(num == 0)
            return 0;
        if(num == 1 )
            return 1;
        else {
            return printFibonacci(num-1) + printFibonacci(num-2);
        }
    }

    public static void main(String[] args) {
        System.out.println(printFibonacci(4));
    }
}
