package org.example.recursion.ds;

import org.example.collections.list.LinkedListNode;

public class BinaryTree {

    public BinaryNode root;
    public BinaryTree(BinaryNode binaryNode){
        this.root = binaryNode;
    }
    public BinaryTree() {}
    public boolean insert(int value) {
        root = recursive_insert(this.root, value);
        return true;
    }

    private BinaryNode recursive_insert(BinaryNode currentNode, int value) {

        if(currentNode == null) {
            return new BinaryNode(value);
        }
        if(value > currentNode.getValue()) {
            currentNode.setRight(recursive_insert(currentNode.getRight(), value));
        }else if(value < currentNode.getValue()) {
            currentNode.setLeft(recursive_insert(currentNode.getLeft(), value));
        } else {
            return currentNode;
        }

        return currentNode;
    }

    public BinaryNode getRoot() {
        return root;
    }
    public void setRoot(BinaryNode root) {
        this.root = root;
    }
    //Function to check if Tree is empty or not
    public boolean isEmpty() {
        return root == null; //if root is null then it means Tree is empty
    }

    static class BinaryNode {
        int value;
        BinaryNode left;
        BinaryNode right;

        public BinaryNode(int value){
            this.value = value;
            this.left = null;
            this.right = null;
        }

        public int getValue() {
            return value;
        }

        public void setValue(int value) {
            this.value = value;
        }

        public BinaryNode getLeft() {
            return left;
        }

        public void setLeft(BinaryNode left) {
            this.left = left;
        }

        public BinaryNode getRight() {
            return right;
        }

        public void setRight(BinaryNode right) {
            this.right = right;
        }
    }

    public void printTree(BinaryNode current) {

        if (current == null) return;

        System.out.print(current.getValue() + ",");
        printTree(current.getLeft());
        printTree(current.getRight());

    }

    public static void main(String args[]) {

        BinaryTree bTree = new BinaryTree();
        bTree.insert(6);
        bTree.insert(4);
        bTree.insert(8);
        bTree.insert(5);
        bTree.insert(2);
        bTree.insert(8);
        bTree.insert(12);
        bTree.insert(10);
        bTree.insert(14);
        bTree.printTree(bTree.getRoot());
    }
}
