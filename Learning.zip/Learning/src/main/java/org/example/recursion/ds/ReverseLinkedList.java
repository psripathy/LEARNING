package org.example.recursion.ds;
import org.example.collections.list.LinkedList;
import org.example.collections.list.LinkedListNode;
import org.example.collections.list.MyLinkedList;
public class ReverseLinkedList {

    private static void reverse(LinkedListNode inputNode) {

        if(inputNode == null){
            return;
        }else {
            reverse(inputNode.next);
            System.out.print(inputNode.data + " ");
        }
    }

    public static void main(String[] args) {

        LinkedList<Integer> input = new LinkedList<>();
        input.createLinkedList(new int[]{1,2,3,4,5});
        input.printLinkedList();
        System.out.println("\n-----------------");
        reverse(input.head);
    }
}
