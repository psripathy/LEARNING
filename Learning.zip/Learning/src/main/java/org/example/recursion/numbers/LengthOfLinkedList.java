package org.example.recursion.numbers;

import org.example.collections.list.LinkedListNode;

import java.util.Iterator;
import java.util.LinkedList;

public class LengthOfLinkedList {
    static int lengthByIteration(LinkedList llist){

        int count = 0;
        Iterator it = llist.iterator();
        while(it.hasNext() && it.next()!=null){
            count++;
        }
        return count;
    }

    static int lengthByRecursion(LinkedList llist){


        return 0;
    }

    public static void main(String[] args) {

        LinkedList<String> llist = new LinkedList<>();
        llist.push("1");
        llist.push("2");
        llist.push("3");
        llist.push("4");
        llist.push("5");


        System.out.println("Count of nodes is = " + lengthByIteration(llist));
    }
}
