package org.example.fastandslow;

public class HappyNumber {

    public static void main(String[] args) {
        System.out.println(isHappyNumber(523));
    }

    static boolean isHappyNumber(int num){
        int slow = num, fast = sumOfSquareOfDigits(num);
        while(fast !=1 && fast != slow){
            slow = sumOfSquareOfDigits(slow);
            fast = sumOfSquareOfDigits(sumOfSquareOfDigits(fast));
        }

        return fast == 1;
    }

    static int sumOfSquareOfDigits(int num){
        int result = 0;
        while(num !=0){
            int digit = num % 10;
            num = num/10;
            result += Math.pow(digit, 2);
        }
        return result;
    }
}
