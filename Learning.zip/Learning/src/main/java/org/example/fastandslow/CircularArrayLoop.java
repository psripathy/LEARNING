package org.example.fastandslow;

public class CircularArrayLoop {

    static boolean checkForLoop(int[] inputArray){

        int size = inputArray.length;

        for (int i = 0; i < size; i++) {
            int slow = i, fast = i;
            boolean forward = inputArray[i] > 0;

            while (true) {
                slow = nextStep(slow, inputArray[slow], size);

                if (isNotCycle(inputArray, forward, slow))
                    break;

                fast = nextStep(fast, inputArray[fast], size);

                if (isNotCycle(inputArray, forward, fast))
                    break;

                fast = nextStep(fast, inputArray[fast], size);

                if (isNotCycle(inputArray, forward, fast))
                    break;

                if (slow == fast)
                    return true;
            }
        }

        return false;
    }

    // A function to calculate the next step
    public static int nextStep(int pointer, int value, int size) {
        int result = (pointer + value) % size;
        if (result < 0)
            result += size;
        return result;
    }

    // A function to detect a cycle doesn't exist
    public static boolean isNotCycle(int[] nums, boolean prevDirection, int pointer) {
        boolean currDirection = nums[pointer] >= 0;

        if (prevDirection != currDirection || Math.abs(nums[pointer] % nums.length) == 0) {
            return true;
        }

        return false;
    }

    public static void main(String[] args) {
        System.out.println(checkForLoop(new int[]{1,3,-2,-4,1}));
        System.out.println(checkForLoop(new int[]{2,1,-1,-2,2}));
    }
}
