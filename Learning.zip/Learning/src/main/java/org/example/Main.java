package org.example;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public static void main(String[] args) {


        System.out.println("Hello world!");
        int num = 43512;
        String [] temp = String.valueOf(num).split("");

        Arrays.sort(temp, Collections.reverseOrder());
        String str = Arrays.toString(temp);

        Arrays.asList(temp);

    }

}