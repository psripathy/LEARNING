package org.example.twopointer;

public class MedianOfTwoArrays {
    static int findMedianOfTwoSortedArrays(int[] nums1, int[] nums2) {
        int median = 0;

        return median;
    }

    public static void main(String[] args) {

        int[] nums1 = {1,2}; int[] nums2 = {3,4};
        System.out.println(findMedianOfTwoSortedArrays(nums1, nums2));
    }
}
