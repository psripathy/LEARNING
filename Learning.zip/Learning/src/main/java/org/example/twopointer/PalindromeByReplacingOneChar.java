package org.example.twopointer;

public class PalindromeByReplacingOneChar {

    public static boolean isPalindrome(String s) {
        return checkStr(s, true) ? true : checkStr(s, false);
    }

    public static boolean checkStr(String s, boolean leftPointer){
        int left = 0;
        int right = s.length() - 1;
        while (left <= right) {
            if (s.charAt(left) == s.charAt(right)) {
                left++;
                right--;
            } else {
                if (s.charAt(left + 1) == s.charAt(right) && leftPointer) {
                    left++;
                } else if (s.charAt(left) == s.charAt(right - 1) && !leftPointer) {
                    right--;
                } else {
                    return false;
                }
            }
        }
        return true;
    }
}
