package org.example.twopointer;

public class Palindrome {
    public static boolean isPalindrome(String s) {
        char[] sArray = s.toCharArray();
        int left = 0;
        int right = s.length()-1;
        boolean isPalindrome = true;
        while (left <= right){
            if(sArray[left] != sArray[right]){
                isPalindrome = false;
                break;
            } else {
                left++;
                right--;
            }
        }
        return isPalindrome;
    }

}
