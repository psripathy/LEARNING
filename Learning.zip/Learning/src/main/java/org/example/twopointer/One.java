package org.example.twopointer;

import java.util.*;

public class One {
    public static void main(String[] args) {
        One one = new One();

        int[] nums1 = {1,2}; int[] nums2 = {3,4};
        System.out.println(one.findMedianSortedArrays(nums1, nums2));
        System.out.println(one.longestPalindrome("cbbd"));
        findDuplicates(new int[] {2, 1, 12, 3, 5, 7, 8, 6, 2, 3, 4, 5});
    }

    public static List<Integer> findDuplicates(int[] nums) {
        List<Integer> duplicates = new ArrayList<>();

        int i = 0;
        while (i < nums.length) {
            if (nums[i] != i + 1) {
                int j = nums[i] - 1;
                if (nums[i] != nums[j]) {
                    swap(nums, i, j);
                } else {
                    duplicates.add(nums[i]);
                    i++;
                }
            } else {
                i++;
            }
        }

        return duplicates;
    }

    private static void swap(int[] nums, int i, int j) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }

    public double findMedianSortedArrays(int[] nums1, int[] nums2) {

        int num1Length = nums1.length;
        int num2Length = nums2.length;
        int mergedLength = num1Length + num2Length;
        int[] mergedArray = new int[mergedLength];
        System.arraycopy(nums1, 0, mergedArray, 0, num1Length);
        System.arraycopy(nums2, 0, mergedArray, num1Length, num2Length);
        Arrays.sort(mergedArray);

        double median = 0d;
        if (mergedArray.length % 2 == 0) {
            median = (double)(mergedArray[mergedArray.length/2] + mergedArray[mergedArray.length/2-1])/2;
        }else {
            median = (double)mergedArray[mergedArray.length/2]/2;
        }
        return median;
    }
    public int lengthOfLongestSubstring(String s) {
        int right = 0;
        int maxLen = Integer.MIN_VALUE;
        HashSet<Character> set = new HashSet<>();

        while(right < s.length()){
            if(set.add(s.charAt(right))){
                right++;
            }else{
                maxLen = Math.max(maxLen, set.size());
                set.clear();
            }
        }
        return maxLen;
    }

    public String longestPalindrome(String s) {
        if(s.length()<2){
            return s;
        }
        int left  = 0;
        int right = left+1;
        String longestPalindrome = "";
        String temp = "";
        while(left<=right && right<s.length()){
            temp = s.substring(left,right+1);
            if(temp.equalsIgnoreCase(new StringBuffer(temp).reverse().toString()) && temp.length()>longestPalindrome.length()){
                longestPalindrome = temp;
                left++;
            }
            right++;
        }
        return longestPalindrome;
    }
}
