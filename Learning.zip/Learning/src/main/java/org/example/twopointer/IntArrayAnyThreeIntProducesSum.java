package org.example.twopointer;

import java.util.Arrays;

public class IntArrayAnyThreeIntProducesSum {
    public static boolean findSumOfThree(int[] nums, int target) {
        //[-1, 2, 1, -4, 5, -3] , 0

        Arrays.sort(nums);
        //target = 0
        //1,2,3,4,5,7,8
        for(int i=0; i<nums.length-2; i++){
            //i=1
            var left = i+1;   //_2
            var right = i+2;  //_3
            var tempSum = nums[i] + nums[left]; // -1

            while (right < nums.length) { // _6 < _7
                tempSum += nums[right]; //8+8 = 16
                if(target == tempSum)   //20 == 16
                    return true;
                else {
                    tempSum = (tempSum - nums[left]); //16-7 = 9
                    left++;  //_6
                    right++; //_7
                }
            }
        }

        return false;
    }
}
