package org.example.general;

import java.util.Stack;

public class StackRemoveAdjacentDuplicateCharacters {

    static String removeDuplicates(String inputStr){
        Stack<Character> calculationStack = new Stack<>();
        for(char currentChar : inputStr.toCharArray()){
            if(!calculationStack.isEmpty() && calculationStack.peek() == currentChar){
                calculationStack.pop();
            }else {
                calculationStack.push(currentChar);
            }
        }

        StringBuilder result = new StringBuilder();
        while(!calculationStack.isEmpty()){
            result.insert(0, calculationStack.pop());
        }

        return result.toString();
    }

    public static void main(String[] args) {
        System.out.println(removeDuplicates("azbbzybaab"));
    }
}
