package org.example.general;

import java.util.HashSet;

public class LargestSubArrayContiguousElements {

    public static int getLongestLength(int arr[]) {
        int l = arr.length;
        int maxLength = 1;
        for (int i=0; i< l-1; i++)
        {
            HashSet<Integer> mySet = new HashSet<>();
            mySet.add(arr[i]);
            int min = arr[i];
            int max = arr[i];
            for (int j=i+1; j<l; j++)
            {
                if (mySet.contains(arr[j]))
                    break;
                mySet.add(arr[j]);
                min = Math.min(min, arr[j]);
                max = Math.max(max, arr[j]);
                if (max-min == j-i)
                    maxLength = Math.max(maxLength, max-min+1);
            }
        }
        return maxLength;
    }
    public static void main (String[] args)
    {
        int arr[] = {10, 12, 13, 11, 8, 10};
        System.out.println("Length of the Longest contiguous SubArray is: "+getLongestLength(arr));
    }
}
