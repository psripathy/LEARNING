package org.example.general;

import java.util.Arrays;

public class MaximizeSumOfConsecutiveDifferencesInCircularArray {
    public static int getMaxDiff(int arr[], int n) {
        int output = 0;
        Arrays.sort(arr);
        for (int i = 0; i < n/2; i++)
        {
            output -= (2 * arr[i]);
            output += (2 * arr[n - i - 1]);
        }
        return output;
    }

    public static void main (String[] args) {
        int arr[] = {9, 8, 2, 4 };
        int n = arr.length;
        System.out.println(getMaxDiff(arr, n));
    }
}
