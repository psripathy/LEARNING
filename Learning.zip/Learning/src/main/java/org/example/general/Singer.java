package org.example.general;

import java.util.List;

public class Singer {
    public static boolean singable(List<String> song, String lowestNote, String highestNote) {
        String pitches = "CDEFGAB";

        int lowestOctave = Integer.parseInt(lowestNote.substring(1));
        int highestOctave = Integer.parseInt(highestNote.substring(1));

        int lowestPitchIndex = pitches.indexOf(lowestNote.charAt(0));
        int highestPitchIndex = pitches.indexOf(highestNote.charAt(0));

        for (String note : song) {
            int pitchIndex = pitches.indexOf(note.charAt(0));
            int octave = Integer.parseInt(note.substring(1));

            if (octave < lowestOctave || octave > highestOctave) {
                return false;
            } else if (octave == lowestOctave && pitchIndex < lowestPitchIndex) {
                return false;
            } else if (octave == highestOctave && pitchIndex > highestPitchIndex) {
                return false;
            }
        }

        return true;
    }

    public static void main(String[] args) {
        // Test cases
        List<String> song1 = List.of("F4", "B4", "C5");
        System.out.println(singable(song1, "F4", "C5")); // Output: true
        System.out.println(singable(song1, "A4", "C5")); // Output: false

        List<String> song2 = List.of("C3", "E3", "G3", "C4", "E4", "G4", "C5");
        System.out.println(singable(song2, "B2", "C5")); // Output: true
        System.out.println(singable(song2, "C3", "B4")); // Output: false

        List<String> song3 = List.of("B4", "F5", "B5");
        System.out.println(singable(song3, "B4", "B5")); // Output: true
        System.out.println(singable(song3, "B4", "C5")); // Output: false

        // Additional test cases
        List<String> song4 = List.of("B4", "E4", "G4", "G4", "A4", "B4", "E4", "B4", "E4", "G4", "G4", "A4", "C5", "B4", "E5", "G4", "G4", "A4", "B4", "C5", "D5", "C5", "B4", "C5", "E5", "D5", "C5", "C5", "B4", "B4", "E5", "E4", "G4", "G4", "A4", "B4", "B4", "B4", "C5", "E5", "A5", "E5", "C5", "A4", "E5", "D5", "C5", "B4");
        System.out.println(singable(song4, "D4", "A5")); // Output: true
        System.out.println(singable(song4, "D4", "G5")); // Output: false
        System.out.println(singable(song4, "D4", "C6")); // Output: true
        System.out.println(singable(song4, "F4", "C6")); // Output: false

        List<String> song5 = List.of("F4");
        System.out.println(singable(song5, "D4", "E4")); // Output: false
    }
}
