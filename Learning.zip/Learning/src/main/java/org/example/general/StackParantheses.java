package org.example.general;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StackParantheses {
    public String minRemoveParentheses(String s) {
        List<Pair<Character, Integer>> stack = new ArrayList<>();
        StringBuilder sList = new StringBuilder(s);

        for (int i = 0; i < s.length(); i++) {
            char val = s.charAt(i);

            // if stack is not empty and top element of stack is an opening parenthesis
            // and the current element is a closing parenthesis
            if (!stack.isEmpty() && stack.get(stack.size() - 1).getFirst() == '(' && val == ')') {

                // pop the opening parenthesis as it makes a valid pair
                // with the current closing parenthesis
                stack.remove(stack.size() - 1);
            }
            // if the current value is an opening or a closing parenthesis
            else if (val == '(' || val == ')') {

                // push onto stack
                stack.add(new Pair<>(val, i));
            }
        }

        // Remove the invalid parentheses
        while (!stack.isEmpty()) {
            int index = stack.get(stack.size() - 1).getSecond();
            sList.deleteCharAt(index);
            stack.remove(stack.size() - 1);
        }

        // convert the list to string
        return sList.toString();
    }


    class Pair<T, U> {
        private T first;
        private U second;

        public Pair(T first, U second) {
            this.first = first;
            this.second = second;
        }

        public T getFirst() {
            return first;
        }

        public U getSecond() {
            return second;
        }
    }

    public static void main(String[] args) {

        List<String> inputs = Arrays.asList("ar)ab(abc)abd(", "a)rt)lm(ikgh)", "aq)xy())qf(a(ba)q)",
                "(aw))kk())(w(aa)(bv(wt)r)",  "(qi)(kl)((y(yt))(r(q(g)s)");
        for (int i = 0; i < inputs.size(); i++) {
            System.out.println(Integer.toString(i + 1) + ". Input: " + inputs.get(i));
            System.out.println("   Valid parentheses, after minimum removal: "
                    + new StackParantheses().minRemoveParentheses(inputs.get(i)));
            System.out.println(new String(new char[100]).replace('\0', '-'));
        }
    }
}


