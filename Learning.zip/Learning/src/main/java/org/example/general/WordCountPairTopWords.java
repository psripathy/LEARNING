package org.example.general;

import org.example.collections.list.Pair;

import java.util.*;
import java.util.stream.Collectors;

public class WordCountPairTopWords {

    public List<String> find(String[] s, int wordLimit, int minWordLength) {
        final PriorityQueue<String> pq = new PriorityQueue<>(Comparator.comparingInt(str -> Integer.parseInt(str.split(",\\s+")[1])));

        for (String wc : s) {
            if (wc.split(",\\s+")[0].length() >= minWordLength) pq.offer(wc);
            if (pq.size() > wordLimit) pq.poll();
        }

        final LinkedList<String> res = new LinkedList<>();
        while (!pq.isEmpty()) res.addFirst(pq.poll());

        return res;
    }

    public static void main(String... args) {
        final String[] s = {"abc, 500",
                "sadhasjhkgdsak, 230239203",
                "fsgdfssd, 78",
                "sss, 56",
                "ss, 56",
                "sss, 5678",
                "sssdsds, 56",
                "ssssdsd, 56",
        };
        final WordCountPairTopWords tw = new WordCountPairTopWords();
        tw.find(s, 3, 3).forEach(System.out::println);
    }


}
