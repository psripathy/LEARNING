package org.example.general;

import java.util.*;
public class Anagram {

    public static boolean isAnagram(String str1, String str2) {

        if (str1.length() != str2.length()) {
            return false;
        }

        Map<Character, Integer> table = new HashMap<>();

        for (char c : str1.toCharArray()) {
            if (table.containsKey(c)) {
                table.put(c, table.get(c) + 1);
            } else {
                table.put(c, 1);
            }
        }

        for (char c : str2.toCharArray()) {
            if (table.containsKey(c)) {
                table.put(c, table.get(c) - 1);
            } else {


                return false;
            }
        }

        for (int count : table.values()) {

            if (count != 0) {
                return false;
            }
        }

        return true;
    }
}
