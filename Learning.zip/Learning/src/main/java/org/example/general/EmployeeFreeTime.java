package org.example.general;

import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;

public class EmployeeFreeTime {

    class Interval {
        public int start;
        public int end;
        public Interval() {}
        public Interval(int _start, int _end) {
            start = _start;
            end = _end;
        }
    };
    public List<Interval> employeeFreeTime(List<List<Interval>> schedule) {
        // We store the pointers of the intervals instead of intervals themselves
        // int[]{i, j} where i represents the ith employee and
        // j represents the jth interval of the ith employee
        PriorityQueue<int[]> pq = new PriorityQueue<>(schedule.size(),
                (a, b) -> (schedule.get(a[0]).get(a[1]).start
                        - schedule.get(b[0]).get(b[1]).start));

        // Initialize with the first interval of all employees
        for (int i = 0; i < schedule.size(); i += 1) {
            pq.offer(new int[]{i, 0});
        }

        // Initialize the latest ending time
        int latestEnd = schedule.get(pq.peek()[0]).get(0).end;

        List<Interval> res = new LinkedList<>();
        while (!pq.isEmpty()) {
            int[] indices = pq.poll();
            List<Interval> employee = schedule.get(indices[0]);
            Interval cur = employee.get(indices[1]);

            if (cur.start > latestEnd) {
                res.add(new Interval(latestEnd, cur.start));
            }

            if (indices[1] < employee.size() - 1) {
                pq.offer(new int[]{indices[0], indices[1] + 1});
            }
            latestEnd = Math.max(latestEnd, cur.end);
        }
        return res;
    }
}
