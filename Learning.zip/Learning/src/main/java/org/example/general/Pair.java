package org.example.general;

public class Pair {
}
