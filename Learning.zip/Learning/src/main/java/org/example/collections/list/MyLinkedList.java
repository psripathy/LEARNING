package org.example.collections.list;

public class MyLinkedList {

    Node head;
    Node tail;
    int size = 0;
    public MyLinkedList(){
        this.head = null;
        this.tail = null;
    }

    public int get(int index) {
        if (index < 0 || index >= size) {
            return -1;
        }
        Node temp = head;
        for (int i = 0; i < index; i++) {
            temp = temp.next;
        }
        return temp.data;
    }

    public Node getNode(int index) {
        if (index < 0 || index >= size) {
            return null;
        }
        Node temp = head;
        for (int i = 0; i < index; i++) {
            temp = temp.next;
        }
        return temp;
    }
    public void addAtHead(int val) {
        Node newNode = new Node(val);
        if(head == null){
            head = newNode;
            tail = newNode;
        }else {
            newNode.next = head;
            head = newNode;
        }
        size++;
    }

    public void addAtTail(int val) {
        Node newTail = new Node(val);
        if(tail == null){
            head = newTail;
            tail = newTail;
        }else {
            tail.next = newTail;
            tail = newTail;
        }
        size++;
    }

    public boolean isTail(Node node){
        return node.next == null ? true : false;
    }
    public void addAtIndex(int index, int val) {
        if(index < 0 || index > size){
            return;
        }
        if(index==0){
            addAtHead(val);
        }else if(index==size){
            addAtTail(val);
        }else {
            Node newNode = new Node(val);
            Node prev = null;
            Node curr = head;
            for(int i=0; i<index; i++){
                prev = curr;
                curr = curr.next;
            }
            newNode.next = curr;
            prev.next = newNode;
            size++;
        }
    }

    public void deleteAtIndex(int index) {
        if(index > size || index < 0){
            return;
        }
        Node curr = head;
        Node toDelete = null;
        if(index == 0){
            head = curr.next;
            curr.next = null;
        }else {
            for (int i = 1; i <= index; i++) {
                toDelete = curr.next;
                if (i == index) {
                    curr.next = curr.next.next;
                    toDelete = null;
                }
            }
        }
        size--;
    }

    static class Node{
        int data;

        Node next;
        Node prev;

        public Node(int data){
            this.data = data;
            this.next = null;
            this.prev = null;
        }

        public Node(int data, Node next){
            this.data = data;
            this.next = next;
        }

        public Node(int data, Node prev, Node next){
            this.data = data;
            this.next = next;
            this.prev = prev;
        }

        public Node getNext() {
            return next;
        }

        public void setNext(Node next) {
            this.next = next;
        }

        public Node getPrev() {
            return prev;
        }

        public void setPrev(Node prev) {
            this.prev = prev;
        }
    }
}
