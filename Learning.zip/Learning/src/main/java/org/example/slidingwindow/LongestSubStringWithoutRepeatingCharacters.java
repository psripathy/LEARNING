package org.example.slidingwindow;

import java.util.HashSet;

public class LongestSubStringWithoutRepeatingCharacters {

    static int getLongestSubString(String input) {
        int output = Integer.MIN_VALUE;
        HashSet<Character> computeSet = new HashSet<>();
        //int startIdx = 0;
        boolean temp = false;
        for(int endIdx=0; endIdx<input.length(); endIdx++){
            temp = computeSet.add(input.charAt(endIdx));
            if(!temp){
                //startIdx++;
                output = Math.max(output, computeSet.size());
            }
        }

        return output;
    }

    public static void main(String[] args) {
        System.out.println("abcabcbb >>> " + getLongestSubString("ababababa"));
        System.out.println("abcabcbb >>> " + lengthOfLongestSubstring("ababababa"));
    }

    public static int lengthOfLongestSubstring(String s) {
        int right = 0;
        int maxLen = Integer.MIN_VALUE;
        HashSet<Character> set = new HashSet<>();

        while(right < s.length()){
            if(set.add(s.charAt(right))){
                right++;
            }else{
                maxLen = Math.max(maxLen, set.size());
                set.clear();
            }
        }
        return maxLen;
    }
}
