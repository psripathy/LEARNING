package org.example.slidingwindow;

import java.util.HashMap;

public class LongestSubStringLengthWithKDistinctCharacters {
    public static void main(String[] args) {

        System.out.println(getLongestSubStringLengthWithKDistinctChars(new String("AAHHIBC"), 2));
    }

    static int getLongestSubStringLengthWithKDistinctChars(String input, int K){

        int maxLength = Integer.MIN_VALUE;
        int windowStart = 0;
        HashMap<String, Integer> charFrequencyMap = new HashMap<>();
        String currentChar = "";
        for(int windowEnd=0; windowEnd<input.length(); windowEnd++){
            currentChar = String.valueOf(input.charAt(windowEnd));
            charFrequencyMap.put(currentChar, (charFrequencyMap.getOrDefault(currentChar, 0) + 1) );
            if(charFrequencyMap.entrySet().size() > K){
                charFrequencyMap.remove(charFrequencyMap.keySet().stream().findFirst().get());
                windowStart++;
            }
            maxLength = Math.max(maxLength, charFrequencyMap.values().stream().mapToInt(Integer::intValue).sum());
        }
        return maxLength;
    }
}
