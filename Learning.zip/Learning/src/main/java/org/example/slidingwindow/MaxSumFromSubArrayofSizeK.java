package org.example.slidingwindow;

public class MaxSumFromSubArrayofSizeK {

    public static void main(String[] args) {
        System.out.println(findMaxSumFromSubArray(new int[] {4,2,1,7,8,1,2,8,1,0}, 3));
    }

    static int findMaxSumFromSubArray(int[] arr, int k){
        int maxSum = Integer.MIN_VALUE;
        int currentSum = 0;
        int startPos = 0;
        for(int endPos=0; endPos<arr.length; endPos++){
            currentSum += arr[endPos];
            if(endPos-startPos+1 == k ){
                maxSum = Math.max(maxSum, currentSum);
                currentSum -= arr[startPos];
                startPos++;
            }
        }

        return maxSum;
    }
}
