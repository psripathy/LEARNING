package org.example.slidingwindow;

import java.util.*;

public class BiggestNumberInSubArrayOfSizeK {

    public static void main(String[] args) {
        Arrays.stream(BiggestNumberInSubArrayOfSizeK.findMaxNumberInSubArray(new int[]{4, 5, 6, 1, 2, 3}, 2)).forEach(System.out :: print);
    }
    public static int[] findMaxNumberInSubArray(int[] nums, int w) {
        int n = nums.length;
        int[] output = new int[n - w + 1];

        for (int i = 0; i < output.length; i++) {
            output[i] = maxNumberFromWindow(i, i + w - 1, nums);
        }
        return output;
    }

    public static int maxNumberFromWindow(int firstIndex, int lastIndex, int[] arr) {
        int maxNum = Integer.MIN_VALUE;
        for (int i = firstIndex; i <= lastIndex; i++) {
            maxNum = Math.max(maxNum, arr[i]);
        }
        return maxNum;
    }


    /*
    public static Deque<Integer> cleanUp(int i, Deque<Integer> currentWindow, int[] nums) {
        while (currentWindow.size() != 0 && nums[i] >= nums[currentWindow.getLast()]) {
            currentWindow.removeLast();
        }
        return currentWindow;
    }

    // function to find the maximum in all possible windows
    public static int[] findMaxSlidingWindow(int[] nums, int w) {
        if (nums.length == 0) {
            return new int[0];
        }
        if (w > nums.length) {
            w = nums.length;
        }
        int [] output = new int[nums.length - w + 1];
        Deque<Integer> currentWindow = new ArrayDeque<>();
        for (int i = 0; i < w; i++) {
            currentWindow = SlidingWindowMaximum.cleanUp(i, currentWindow, nums);
            currentWindow.add(i);
        }
        output[0] = nums[currentWindow.getFirst()];
        for (int i = w; i < nums.length; i++) {
            cleanUp(i, currentWindow, nums);
            if (!currentWindow.isEmpty() && currentWindow.getFirst() <= (i - w)) {
                currentWindow.removeFirst();
            }
            currentWindow.add(i);
            output[i - w + 1] = nums[currentWindow.getFirst()];
        }
        return output;
    }
*/

}
