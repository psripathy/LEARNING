package org.example.slidingwindow;

public class SmallestSubArrayOfSumK {

    public static void main(String[] args) {
        System.out.println("---> " + smallestSubArray(new int[] {1,2,3,4,5,6}, 10));
    }

    static int smallestSubArray(int[] nums, int k){
        int minWindowSize = Integer.MAX_VALUE;
        int currentWindowSum = 0, windowStart = 0;

        for(int windowEnd=0; windowEnd < nums.length; windowEnd++){
            currentWindowSum += nums[windowEnd];

            while(currentWindowSum >= k){
                minWindowSize = Math.min(minWindowSize, windowEnd-windowStart+1);
                currentWindowSum -= nums[windowStart];
                windowStart++;
            }

        }
        return minWindowSize;
    }
}
