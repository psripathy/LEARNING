package org.example.slidingwindow;

import java.util.HashMap;

public class LongestSubStringWithSameCharAfterKReplacements {

    static int getLengthOfLongestSubString(String inputStr, int K){

        int maxLength = Integer.MIN_VALUE;
        int mostFrequentChar = 0;
        int startIdx = 0;
        HashMap<Character, Integer> charFrequencyMap = new HashMap<>();
        for(int endIdx=0; endIdx < inputStr.length(); endIdx++){
            char currentChar = inputStr.charAt(endIdx);
            charFrequencyMap.put(currentChar, charFrequencyMap.getOrDefault(currentChar, 0)+1);
            mostFrequentChar = Math.max(mostFrequentChar, charFrequencyMap.get(currentChar));
            if(endIdx - startIdx +1 - mostFrequentChar > K){
                charFrequencyMap.put(inputStr.charAt(startIdx), charFrequencyMap.get(inputStr.charAt(startIdx))-1);
                startIdx+=1;
            }
            maxLength = Math.max(maxLength, endIdx-startIdx+1);
        }
        return maxLength;
    }

    public static void main(String[] args) {
        System.out.println("dippitydip, 4 >> " + (getLengthOfLongestSubString("dippitydip", 4) == 6)); //6
        System.out.println("aaacbbbaabab, 2 >> " + (getLengthOfLongestSubString("aaacbbbaabab", 2) == 6)); //6
    }
}
