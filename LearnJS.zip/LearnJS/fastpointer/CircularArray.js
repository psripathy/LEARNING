isCircular = (nums) => {

    let beginIndex = 0;
    let size = nums.length
    for(let i=0; i<nums.length; i++){
        let slow = i, fast = i;
        let forward = nums[i] > 0;
        while (true) {
            slow = nextStep(slow, nums[slow], size);

            if (isNotCycle(nums, forward, slow))
                break;

            fast = nextStep(fast, nums[fast], size);
            if (isNotCycle(nums, forward, fast))
                break;

            fast = nextStep(fast, nums[fast], size);

            if (isNotCycle(nums, forward, fast))
                break;

            if (slow == fast)
                return true;
        }
    }

    return false
}

nextStep = (pointer, value, size) => {
    let result = (pointer + value) % size;
    if (result < 0)
        result += size;
    return result;
}

isNotCycle = (nums, prevDirection, pointer) => {
    currDirection = nums[pointer] >= 0;

    if (prevDirection != currDirection || Math.abs(nums[pointer] % nums.length) == 0) {
        return true;
    }

    return false;
}

let input = [1,3,-2,-4,1]
console.log(">> " + isCircular(input))
