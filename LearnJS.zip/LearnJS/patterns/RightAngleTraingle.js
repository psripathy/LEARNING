printStar = (num) => {

    for(let i=1; i<= num; i++){
        let arr = Array(i).fill("*");
        console.log(...arr);
    }
}

printNum = (num) => {

    for(let i=1; i<= num; i++){
        let arr = Array(i).fill(i);
        console.log(...arr);
    }
}

print = (num) => {

    let arr = [];
    for(let i=1; i<= num; i++){
        arr.push(i)
        console.log(...arr);
    }
}

printUpside = (num) => {

    let arr = Array(num).fill().map((_, i) => i+1);//.reverse();
    for(let i=0; i<num; i++){
        console.log(...arr)
        arr.pop();
    }
    
}


printStar(5);
console.log("------------")
printNum(5);
console.log("------------")
print(5);
console.log("------------")
printUpside(5);
