
printPyramid = (num) => {

    for(let i=1; i<=num; i++){

        let stars = [];
        for(let x=1;x<=num-i; x++){
            stars.push(" ");
        }

        for(let y=1;y<=2*i-1;y++){
            stars.push("*")
        }

        console.log(stars.join(''));
    }
}

printInvertedPyramid = (num) => {

    for(let i=num; i>=1; i--) {
        let stars = [];
        for(let x=1;x<=num-i; x++){
            stars.push(" ");
        }

        for(let y=1;y<=2*i-1;y++){
            stars.push("*")
        }

        console.log(stars.join(''));
    }
}

combinePyramid = (num) => {

    let tempArr = [];
    for(let i=num; i>=1; i--) {
        let stars = [];
        for(let x=1;x<=num-i; x++){
            stars.push(" ");
        }

        for(let y=1;y<=2*i-1;y++){
            stars.push("*")
        }

        tempArr.push(stars.join(''));
        console.log(stars.join(''));
    }
    for(let j=tempArr.length-1; j>=0; j--){
        console.log(tempArr[j])
    }
}

printPyramid(5);
console.log("------------")
printInvertedPyramid(5);
console.log("------------")
combinePyramid(5)