LinkedList = (size) => {
    this.head = null;
    this.size = 0;
}

Node = (data) => {
    this.data = data;
    this.next = null;
}

LinkedList.prototype.add = (data) => {
    let newNode = new Node(data);
    if(this.head == null){
        this.head = newNode
    } else {
        let currentNode = this.head
        while(currentNode.next != null){
            currentNode = currentNode.next;
        }
        currentNode.next = newNode
    }
    this.size++
}

LinkedList.prototype.remove = (data) => {
    let currentNode = this.head
    let prevNode = null
    while(currentNode != null){
        if(currentNode.data === data){
            if(prevNode === null)
                this.head = currentNode.next
            else
                prevNode.next = currentNode.next
            this.size--;
            break;
        }
    }

    prevNode = currentNode
    currentNode = currentNode.next
}

LinkedList.prototype.search = (data) => {
    let currentNode = this.head
    while(null != currentNode){
        if(currentNode.data === data){
            return currentNode;
        }
        currentNode = currentNode.next
    }
    return null;
}