checkSum= (inputArr, K) => {

    inputArr.sort(function(a,b){
        return a-b;
    })

    for(let i=0; i<inputArr.length;i++){
        let leftPointer = i+1;
        let rightPointer = inputArr.length-1;
        let sum = inputArr[i]+inputArr[leftPointer] + inputArr[rightPointer];
        while(leftPointer<rightPointer){
            if(sum == K)
                return true
            if(sum < K){
                sum -= inputArr[leftPointer]
                leftPointer++
                sum += inputArr[leftPointer];
            }else {
                sum -= inputArr[rightPointer]
                rightPointer--
                sum += inputArr[rightPointer];
            }
        }
    }
    return false
}

let input = [-1,2,1,-4,5,-3];
let k = 0;
console.log(checkSum(input, k));