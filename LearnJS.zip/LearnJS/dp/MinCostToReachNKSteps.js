//optimal solution = 30 > 60 > 50 = 40
let stops=[30, 20, 10, 60, 10, 60, 50];
let dest=stops.length-1;
let K=3;

getMinCostToReachDestByRecursion = (stopsArr, currIndex) => {

    if(currIndex == 0) return 0;
    if(currIndex == 1) return stopsArr[1] - stopsArr[0];
    let currentMin = Number.MAX_SAFE_INTEGER;
    for(let x=1; x<=K; x++){
        let temp = currIndex-x;
        if(temp >= 0)
            currentMin = Math.min(currentMin, (getMinCostToReachDestByRecursion(stopsArr, temp) + Math.abs(stopsArr[currIndex] - stopsArr[temp])) );
    }
    return currentMin;
}

getMinCostToReachDestByMemoization = (stopsArr, currIndex, mem) => {

    if(currIndex == 0) return mem[0] = 0;
    if(currIndex == 1) return mem[1] = stopsArr[1] - stopsArr[0];
    if(mem[currIndex] != -1) return mem[currIndex];
    let currentMin = Number.MAX_SAFE_INTEGER;
    for(let i=1;i<=K; i++){
        let temp = currIndex-1;
        if(temp>=0){
            let jump = Math.abs(stopsArr[currIndex] - stopsArr[temp]);
            currentMin = Math.min(currentMin, (getMinCostToReachDestByRecursion(stopsArr, temp) + jump) );
        }
    }
    return mem[currIndex] = currentMin;
}

getMinCostToReachDestBottomUp = (stopsArr) => {
    let tempArr = Array(stopsArr.length).fill(0);
    tempArr[0] = 0;
    tempArr[1] = stopsArr[1] - stopsArr[0];
    for(let i=2; i<stopsArr.length; i++){
        let currentMin = Number.MAX_SAFE_INTEGER;
        let prev2 = 0, prev = 0;
        for(j=1;j<=K;j++){
            let currIndex = i-j;
            if(currIndex >=0 ){
                currentMin = Math.min(currentMin, tempArr[currIndex]+Math.abs(stopsArr[i] - stopsArr[currIndex])); 
            }
        }
        tempArr[i] = currentMin;
    }
    return tempArr[stopsArr.length-1];
}

console.log("getMinCostToReachDestByRecursion >> " + getMinCostToReachDestByRecursion(stops, dest));
let tempMem = Array(stops.length).fill(-1);
console.log("getMinCostToReachDestByMemoization >> " + getMinCostToReachDestByMemoization(stops, dest, tempMem));

console.log("getMinCostToReachDestBottomUp >> " + getMinCostToReachDestBottomUp(stops));