maxSumMemoized = (inputArr, currIndex, memArr) => {

    if(currIndex < 0)
        return 0;
    if(currIndex == 0) return inputArr[0];
    if(memArr[currIndex] != -1) return memArr[currIndex];
    let currMax = 0;
    let idx_2sum = inputArr[currIndex] + maxSumMemoized(inputArr, currIndex-2, memArr);
    let idx_1sum = 0 + maxSumMemoized(inputArr, currIndex-1, memArr);
    currMax = Math.max( idx_2sum, idx_1sum );
    return memArr[currIndex] = currMax;
}

maxSumBottomUpNoRecursion = (inputArr) => {

    let calcArr = Array(inputArr.length).fill(0);
    calcArr[0] = inputArr[0];
    for(let i=1; i<inputArr.length; i++){
        let pick = inputArr[i];
        if(i > 1)
            pick += calcArr[i-2];
        let pick2 = calcArr[i-1];
        console.log(i + " Math. max (" + pick + ", " + pick2 + ")");
        calcArr[i] = Math.max(pick, pick2);
        
    }
    return calcArr[inputArr.length-1];
}

let input = [1,2,3,1,3,5,8,1,9];
let startIdx = input.length-1;
let memArr = Array(input.length).fill(-1);
console.log("maxSumMemoized: 24 == " + maxSumMemoized(input, startIdx, memArr));

console.log("maxSumBottomUpNoRecursion: 24 == " + maxSumBottomUpNoRecursion(input));