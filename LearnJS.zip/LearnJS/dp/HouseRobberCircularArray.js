getMaxValue = (inputArr, skipFirst) => {

    let startIdx = 0, endIdx = inputArr.length-1 ;
    if(skipFirst){
        startIdx = 1;
        endIdx = inputArr.length;
    }
    console.log(startIdx + " - " + endIdx);
    let calcArr = Array(inputArr.length-1).fill(0);
    calcArr[0] = inputArr[startIdx];

    for(let i=startIdx+1; i<endIdx; i++){
        let pick = inputArr[i];
        if(i>startIdx+1)
            pick += calcArr[i-2];
        let pick2 = inputArr[i-1];
        calcArr[i] = Math.max(pick, pick2);
    }
    console.log(calcArr[calcArr.length-1]);
    return calcArr[calcArr.length-1];
}

let houses = [1,5,2,1,6];
console.log("getMaxValue: 11 == " + Math.max( getMaxValue(houses), getMaxValue(houses, true) ) );