let costArr = [30,10,60,10,60,50];
let numOfStairs = 6;

getMinimalCost = (currentPos, costArr) => {

    if(currentPos == 0) return 0;

    let oneStepCost = getMinimalCost(currentPos-1, costArr) + Math.abs(costArr[currentPos-1] - costArr[currentPos]);
    let twoStepCost = Number.MAX_SAFE_INTEGER;
    if(currentPos > 1){
        twoStepCost = getMinimalCost(currentPos-2, costArr) + Math.abs(costArr[currentPos-2] - costArr[currentPos]);
    } 
    return Math.min(oneStepCost, twoStepCost);
}

getMinimalCostMemoization = (currentPos, costArr, calculationArr) => {

    if(currentPos == 0) return 0;
    if(calculationArr[currentPos] != -1) return calculationArr[currentPos];
    let oneStepCost = getMinimalCostMemoization(currentPos-1, costArr, calculationArr) + Math.abs(costArr[currentPos-1] -costArr[currentPos]);
    let twoStepCost = Number.MAX_SAFE_INTEGER;
    if(currentPos > 1){
        twoStepCost = getMinimalCost(currentPos-2, costArr, calculationArr) + Math.abs(costArr[currentPos-2] - costArr[currentPos]);
    }
    calculationArr[currentPos] = Math.min(oneStepCost, twoStepCost);
    return calculationArr[currentPos];

}


getMinimalCostBottomUp = (costArr, calculationArr) => {

    calculationArr[0] = 0;
    let len = costArr.length;
    for(let i=1; i< len; i++){
        let twoStepCost = Number.MAX_SAFE_INTEGER;
        let oneStepCost = calculationArr[i-1] + Math.abs(costArr[i-1] - costArr[i]);        
        if(i > 1){
            twoStepCost = calculationArr[i-2] + Math.abs(costArr[i-2] - costArr[i]);
        }
        calculationArr[i] = Math.min(oneStepCost, twoStepCost);
    }
    return calculationArr[len-1];
}

getMinimalCostBottomUpSpaceOptimized = (costArr) => {


    let step1 = 0;
    let step2 = 0;
    for(let i=1; i<costArr.length; i++){
        let twoStepCost = Number.MAX_SAFE_INTEGER;
        let oneStepCost = step1 + Math.abs(costArr[i-1] - costArr[i]);        
        if(i > 1){
            twoStepCost = step2 + Math.abs(costArr[i-2] - costArr[i]);
        }
        let curr = Math.min(oneStepCost, twoStepCost);
        step2 = step1;
        step1 = curr;
    }
    return step1;
}

console.log("getMinimalCost >> " + getMinimalCost(numOfStairs-1, costArr));
console.log("getMinimalCost >> " + getMinimalCost(3, [10,20,30,10]));
let calcArr = Array(numOfStairs).fill(-1);
console.log("getMinimalCostMemoization >> " + getMinimalCostMemoization(numOfStairs-1, costArr, calcArr));
console.log("getMinimalCostBottomUp >> " + getMinimalCostBottomUp(costArr, calcArr));
console.log("getMinimalCostBottomUpSpaceOptimized >> " + getMinimalCostBottomUpSpaceOptimized(costArr));