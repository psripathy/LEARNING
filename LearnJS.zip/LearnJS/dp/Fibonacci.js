FibonacciByRecursion = (n) => {
  
    if(n <= 1){
        return n;
    }
    return FibonacciByRecursion(n-1) + FibonacciByRecursion(n-2);
};

fibonacciDPMemoization = (n, arr) => {

    if(n <= 1) return n;
    if(arr[n]) return arr[n];
    arr[n] = fibonacciDPMemoization(n-1, arr) + fibonacciDPMemoization(n-2, arr);
    return arr[n];
}

fibonacciBottomUp = (n, arr) => {
    arr[0] = 0;
    arr[1] = 1;
    for(var i=2; i<=n; i++) {
        arr[n] = arr[n-1] + arr[n-2];
    }
    
    return arr[n];
}

fibonacciBottomUpSpaceOptimized = (n) => {
    var n_2Fib = 0;
    var n_1Fib = 1;
    for(var i=2;i<=n;i++){
        var fibNow = n_1Fib + n_2Fib;
        n_2Fib = n_1Fib;
        n_1Fib = fibNow;
    }
    return n_1Fib;
}

var fibNum = 5;
let fibArr = [];
console.log("FibonacciByRecursion:5 >> " + FibonacciByRecursion(fibNum));
console.log("fibonacciDPMemoization:5 >> " + fibonacciDPMemoization(fibNum, fibArr));
console.log("fibonacciBottomUp:5 >> " + fibonacciBottomUp(fibNum, fibArr));
console.log("fibonacciBottomUpSpaceOptimized:5 >> " + fibonacciBottomUpSpaceOptimized(fibNum));